import express from "express";
import cors from "cors";
import { errorHandler } from "./middleware/errorHandler";

import authRoutes from "./modules/auth/auth.routes";
import productosRoutes from "./modules/productos/productos.routes";
import ventasRoutes from "./modules/ventas/ventas.routes";

// Módulos pendientes de implementar siguiendo el mismo patrón que productos/ventas:
// categorias, proveedores, compras, clientes, caja, reportes

export const app = express();

app.use(cors());
app.use(express.json());

app.get("/api/v1/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/productos", productosRoutes);
app.use("/api/v1/ventas", ventasRoutes);

// El errorHandler va siempre al final, después de todas las rutas
app.use(errorHandler);
